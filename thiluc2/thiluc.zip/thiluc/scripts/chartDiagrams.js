
ChartDiagrams = function () {
	ChartTypeSingle.call(this, "Tranh minh họa");
	// var index = 0;
	// setInterval(() => {
	// 	var settings = document.getElementById("settings");
	// 	if (index < this.GetNumOptotypes()) {
	// 		$(settings.optoType).val("" + index++);
	// 		this.Render(false);
	// 	} else index = 0;
	// }, 1000);
}


ChartDiagrams.prototype = new ChartTypeSingle();
ChartDiagrams.constructor = ChartDiagrams;

ChartDiagrams.prototype.UpDownMode = function () {
	return "row";
}

ChartDiagrams.ROW_SCALES = [200, 150, 120, 100];

ChartDiagrams.prototype.GetNumRows = function () {
	return ChartDiagrams.ROW_SCALES.length;
}

ChartDiagrams.prototype.GetRowScale = function (index) {
	return ChartDiagrams.ROW_SCALES[index];
}

ChartDiagrams.prototype.GetNumImages = function () {
	return 1;
}

ChartDiagrams.prototype.GetImage = function (index) {
	return "Diagrams/" + (this.optotypeIndex + 1) + '.png';
}

ChartDiagrams.prototype.GetNumOptotypes = function () {
	return 14;
}

ChartDiagrams.prototype.GetOptotypeName = function (index) {
	return "Tranh " + (index + 1);
}

ChartType.Register(new ChartDiagrams());

