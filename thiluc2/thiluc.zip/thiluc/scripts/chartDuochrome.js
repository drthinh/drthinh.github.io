// Nguyễn Đức Thịnh - 2023
ChartDuochrome = function()
{
	ChartTypeSingle.call(this, "Duochrome");
}


ChartDuochrome.prototype = new ChartTypeSingle();
ChartDuochrome.constructor = ChartDuochrome;

ChartDuochrome.prototype.UpDownMode = function()
{
	return "row";
}

ChartDuochrome.ROW_SCALES 	= [200, 150, 120, 100];

ChartDuochrome.prototype.GetNumRows = function()
{
	return ChartDuochrome.ROW_SCALES.length;
}

ChartDuochrome.prototype.GetRowScale = function(index)
{
	return ChartDuochrome.ROW_SCALES[index];
}

ChartDuochrome.prototype.GetNumImages = function() 
{
	return 1;
}

ChartDuochrome.prototype.GetImage = function(index)
{
	return "Duochrome/duochrome";
}


ChartType.Register(new ChartDuochrome());

			