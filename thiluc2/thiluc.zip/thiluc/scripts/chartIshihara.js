// Nguyễn Đức Thinh - 2023
ChartIshihara = function()
{
	ChartTypeSingle.call(this, "Ishihara");
}


ChartIshihara.prototype = new ChartTypeSingle();
ChartIshihara.constructor = ChartIshihara;

ChartIshihara.prototype.UpDownMode = function()
{
	return "row";
}

ChartIshihara.ROW_SCALES = [200, 150, 120, 100];

ChartIshihara.prototype.GetNumRows = function()
{
	return ChartIshihara.ROW_SCALES.length;
}

ChartIshihara.prototype.GetRowScale = function(index)
{
	return ChartIshihara.ROW_SCALES[index];
}

ChartIshihara.prototype.GetNumImages = function() //in optotype.
{
	return 24;
}

ChartIshihara.prototype.GetImage = function(index)
{
	this.SetOptotypeIndex(index);
	return "Ishihara/Plate" + (index+1) +".gif";
}

ChartIshihara.prototype.GetNumOptotypes = function()
{
	return 24;
}

ChartIshihara.prototype.GetOptotypeName = function(index)
{
	return "Tấm " + (index + 1);
}

ChartIshihara.prototype.SetOptotypeIndex = function(index)
{
	var settings = document.getElementById("settings");
	$(settings.optoType).val("" + index);
	ChartTypeSingle.prototype.SetOptotypeIndex.call(this, index);
}


ChartType.Register(new ChartIshihara());

		