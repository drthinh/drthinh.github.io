
ChartMisc = function()
{
	ChartTypeSingle.call(this, "Amsler, Worth");
}


ChartMisc.prototype = new ChartTypeSingle();
ChartMisc.constructor = ChartMisc;

ChartMisc.prototype.UpDownMode = function()
{
	return "row";
}

ChartMisc.ROW_SCALES = [350, 300, 250, 200, 150, 120, 100];

ChartMisc.prototype.GetNumRows = function()
{
	return ChartMisc.ROW_SCALES.length;
}

ChartMisc.prototype.GetRowScale = function(index)
{
	return ChartMisc.ROW_SCALES[index];
}

ChartMisc.prototype.GetNumImages = function()
{
	return 1;
}

ChartMisc.prototype.GetImage = function(index)
{
	return "Misc/" + (this.optotypeIndex+1);
}

ChartMisc.prototype.GetNumOptotypes = function()
{
	return 2;
}

ChartMisc.prototype.GetOptotypeName = function(index)
{
	if(index == 0) return "Bảng Amsler";
	if(index == 1) return "Test 4 điểm Worth";
	return "" + (index + 1);
}

ChartType.Register(new ChartMisc());

		